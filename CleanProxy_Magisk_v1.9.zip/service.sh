#!/system/bin/sh
MODDIR=${0%/*}

# wait network/system
sleep 18

# already running? leave it — do NOT kill
if pgrep -f 'proxy_arm64' >/dev/null 2>&1; then
    exit 0
fi

BIN=""
if [ -x /system/bin/proxy_arm64 ]; then
    BIN=/system/bin/proxy_arm64
elif [ -x "$MODDIR/system/bin/proxy_arm64" ]; then
    BIN="$MODDIR/system/bin/proxy_arm64"
fi
[ -z "$BIN" ] && exit 0

chmod 755 "$BIN" 2>/dev/null

# stale lock cleanup only if process dead
for L in /data/local/tmp/.proxy_arm64.lock /dev/.proxy_arm64.lock /data/adb/.proxy_arm64.lock; do
    if [ -f "$L" ] && ! pgrep -f 'proxy_arm64' >/dev/null 2>&1; then
        rm -f "$L" 2>/dev/null
    fi
done

# start — never kill existing
nohup "$BIN" >/dev/null 2>&1 &
